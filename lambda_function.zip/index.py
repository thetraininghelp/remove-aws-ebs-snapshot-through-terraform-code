import boto3
import json

def handler(event, context):
    snapshot_id = event['snapshot_id']
    ec2 = boto3.client('ec2')
    
    try:
        ec2.delete_snapshot(SnapshotId=snapshot_id)
        return {
            'statusCode': 200,
            'body': json.dumps(f'Snapshot {snapshot_id} deleted successfully.')
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error deleting snapshot {snapshot_id}: {str(e)}')
        }
